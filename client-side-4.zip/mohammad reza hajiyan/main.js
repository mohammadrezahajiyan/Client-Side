
var Video1 = document.getElementById("video"); 
var textvideo = document.getElementById("textvid");

    function playPause() { 
        if (Video1.paused) {
            Video1.play(); 
            textvideo.innerHTML = "نگه داشتن";
        }else{
            Video1.pause(); 
            textvideo.innerHTML = "پخش";
        }

    } 

     function skip(value) {
            var video = document.getElementById("video");
            video.currentTime += value;
     }    

     function restart() {
            var video = document.getElementById("video");
            video.currentTime = 0;
        }